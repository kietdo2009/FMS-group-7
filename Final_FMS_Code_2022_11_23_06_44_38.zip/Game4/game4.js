
var gameState = "START";
var buttonX = 200;
var buttonY = 200;
var distanceToButton = 0.0;
var score = 0;
var secs=0;

function game3Setup() {
  createCanvas(400, 400);
  score=0;
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.show();
  game4Button.hide();
  secs= 0;
  frameCount=0;
  currentActivity=3
	textAlign(CENTER);
	//frameRate(1);
} // end of setup

function game3Draw() {
  background(220);
	
	if(gameState == "START"){
		start();
	}
	
	if(gameState == "GAMEON"){
		gameOn();
	}
	
	if(gameState == "GAMEOVER"){
		gameOver();
	}
    

} // end of draw

///////////////////////////////////////////////
function start(){
	text("SCORE: " + score,width/2,20);
	text("Frame Count: " + frameCount, width/2,40);
	text("GameState: " + gameState, width/2,60);
	
	text("Click Game 3 to Play Again", width/2,height/2);
	if(mouseIsPressed){
		gameState = "GAMEON";
	}
} // end start

function gameOn(){
  background(255,0,255);
  
  distanceToButton = dist(buttonX,buttonY,mouseX,mouseY);
	text("SCORE: " + score,width/2,20);
	text("Frame Count: " + frameCount, width/2,40);
	text("GameState: " + gameState, width/2,60);
    text("Touch the circles in less than 500 Frames", width/2, 100);
	ellipse(buttonX,buttonY,50,50);	
		
	if(distanceToButton <25){  // moves the button when true
		buttonX = random(width);
		buttonY = random(height);
		score += 1;
	}
	
	if(score>=10){  	// ends the game when this is true
		gameState = "GAMEOVER";
    
	}
  if(frameCount>=500){  	// ends the game when this is true
		gameState = "GAMEOVER";
} // end gameOn
}
function gameOver(){
    if (score>=10){
	  background(0, 100,255);
      text("You did it!", width/2,120);
    }
    if (score<9){
      background(128);
      text("Better luck next time", width/2,120);
    }
	text("SCORE: " + score,width/2,20);
	
    
	text("GameState: " + gameState, width/2,60);
	
	text("GAME OVER", width/2,100);
    
	text("Click Game 3 to Play Again", width/2,200);
	if(mouseIsPressed){
		gameState = "START";
	}
} // end game Over
