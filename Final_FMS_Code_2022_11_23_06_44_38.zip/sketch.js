let StartScreen;
let gameScreen;
let currentActivity = 0;
let menuButton, game1Button, game2Button, game3Button, game4Button;


function switchToMM(){
  image(StartScreen,0,0,640,360)
  currentActivity = 0;
  menuButton.hide();
  game1Button.show();
  game2Button.show();
  game3Button.show();
  game4Button.show();
}
function setup() {
  createCanvas(640, 360);
  StartScreen = loadImage('Screenshot (40).png');
    //dont work bruv
  gameScreen = loadImage('Screenshot (45).png');
  
  menuButton = createButton('Home Page');
  menuButton.position(0, 338);
  menuButton.mousePressed(switchToMM);
  menuButton.hide();
  
  game1Button = createButton('Game 1');
  game1Button.position(75, 75);
  game1Button.mousePressed(game1Setup);
  game1Button.show();
  
  game2Button = createButton('Game 2');
  game2Button.position(75, 145);
  game2Button.mousePressed(game2Setup);
  game2Button.show();
  
  game3Button = createButton('Game 3');
  game3Button.position(77, 215);
  game3Button.mousePressed(game3Setup);
  game3Button.show();
  
  game4Button = createButton('Credits');
  game4Button.position(80.5, 290);
  game4Button.mousePressed(game4Setup);
  game4Button.show();
  
}
function draw() {  
  switch(currentActivity){
    case 0: 
      mainMenu();
      break;
    case 1: 
      game1Draw();
      break;
    case 2: 
      game2Draw();
      break;
    case 3: 
      game3Draw();
      break;
    case 4: 
      game4Draw();
      break;
  }
}
  

function mainMenu(){
  createCanvas(640,360);
  
  image(StartScreen,0,0,640,360)
  
  
  
}

function mousePressed(){

  switch(currentActivity){
    case 1: 
      mousePressed1();
      break;
  }
}