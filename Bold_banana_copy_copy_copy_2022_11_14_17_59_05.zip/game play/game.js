let d = 40;
let col = 0;
let times = [];
let now;
let txt = "Click now to play.";


function game1Setup(){
  currentActivity=1;
  
  menuButton.show();
  game1Button.hide();
  game2Button.show();
  game3Button.show();
  createCanvas(640, 360);
  let d = 40;
  let col = 0;
  let times = [];
  let now;
  let txt = "Click now to play.";
}
function game1Draw(){
  
  
  background(51,187,255);
  
  noStroke();
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(16);
  text(txt, width/2, height/2);
  
  if (txt != "Click now to play.") {
    text('Click When it turns Yellow!', 320, 50)
    stroke(255);
    line(50, 20, width-50, 20);
    for (let i of times) {
      noStroke();
      fill(255, 255, 0, 230);
      circle(50 + i*400, 20, 10);
    }
  }
  
  if (txt == "") {
    noStroke();
    fill(255, col, 0);
    circle(width/2, height/2, d);
  }
}

function timeoutChange(changeSize) {
  const time = random(1500, 4000);
  setTimeout(() => {
    col = 255;
    now = millis();
    if (changeSize) {
      d = width;
    }
  }, time);
}

function mousePressed1() {
  if (txt != "") {
    d = 40;
    txt = "";
    times.splice(0, 5);
    timeoutChange();
  } else {
    col = 0;
    const reactionTime = (millis() - now) / 1000;
    times.push(reactionTime);
    if (times.length < 5) {
      timeoutChange(times.length == 4);
    } else {
      let avg = 0;
      let description = "";
      for (let i of times) {
        avg += i;
      }
      avg /= times.length;
      if (avg < 0.22) {
        description = "That was super fast!";
      } else if (avg < 0.28) {
        description = "That was very fast!";
      } else if (avg < 0.34) {
        description = "That was fast.";
      } else if (avg < 0.38) {
        description = "Well done.";
      }
      txt = `${avg.toFixed(3)}
${description}
Click to play again.`;
    }
  }


}