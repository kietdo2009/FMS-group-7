let creditsScreen;

function game4Setup(){
  currentActivity=4;
  creditsScreen=loadImage('Screenshot (45).png');
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  game4Button.hide();
}
function game4Draw(){
  image(creditsScreen,0,0,640,360);
}