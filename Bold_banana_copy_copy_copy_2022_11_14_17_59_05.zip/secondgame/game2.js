var rectW = 200; //rectangle starts in the middle
let timer=0;
function game2Setup(){
  currentActivity=2;
  
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  game4Button.hide();
  createCanvas(400, 400);
  
  
  
  
}
function game2Draw(){
  
  gamestart();
}

function gamestart() {
  background(102, 209, 252); //blue color

  noStroke();
  fill(123, 9, 184); //purple color
  rect(0, 0, rectW, height);

  textAlign(CENTER);
  textSize(40);
  fill(255);

  //display message if purple wins (rect width is the same size as the canvas)
  if (rectW == 400) {
    text("PURPLE WINS", width / 2, height / 2);
    textSize(20);
    text("Hit the R key to restart the game", width / 2, height / 2 + 60);
  }
  
  //display message if blue wins (rect width is equal to 0)
  if (rectW == 0) {
    text("BLUE WINS", width / 2, height / 2);
    textSize(20);
    text("Hit the R key to restart the game", width / 2, height / 2 + 60);
    
    }
    
      if (millis()>150+timer &&rectW > 0 && rectW < 400){
      rectW+=5;
      timer=millis();
  }
  textSize(15);
  text("Start the game and hit the 'q' key for blue colour to win!",200,20)

}

function keyPressed() {

  //if "p" key is pressed AND rect width is between 0 and 400, increase the width
  if (key == "p" && rectW > 0 && rectW < 400) {
    rectW += 10;
  }

    //if "q" key is pressed AND rect width is between 0 and 400, decrease the width
  if (key == "q" && rectW > 0 && rectW < 400) {
    rectW -= 10;
  }

  //if "r" key is pressed, reset rect width to the middle of the canvas
  if (key == "r") {
    rectW = 200;
  }

}